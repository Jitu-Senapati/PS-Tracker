import { readFileSync } from 'node:fs';
const t = readFileSync('flip.html', 'utf8');
const labels = [...t.matchAll(/>(Currently unavailable|Coming Soon|Sold Out|Out of stock)<\/div>/gi)].map(m => ({ i: m.index, s: m[1] }));
const titles = [...t.matchAll(/<a[^>]*href="([^"]*\/p\/itm[^"]*)"[^>]*><span[^>]*>([^<]{5,160})<\/span><\/a>/g)].map(m => ({ i: m.index, u: m[1], n: m[2] }));
let prev = -1, msg = 'FULL IDS\n';
for (const x of titles) {
  const lab = labels.filter(l => l.i > prev && l.i < x.i).pop(); prev = x.i;
  const id = (x.u.match(/\/p\/(itm[a-z0-9]+)/i) || [])[1];
  const amt = (x.n.match(/Rs\.?\s?(\d{3,5})/i) || x.n.match(/(\d{3,5})\s*INR/i) || x.n.match(/: (\d{3,5})/) || [])[1] || '?';
  msg += amt + ' | ' + (lab ? lab.s : 'NO LABEL') + ' | ' + id + '\n';
}
for (const name of ['Rs.7000 Store Gift Card', 'Rs.9000 Store Gift Card']) {
  const i = t.indexOf(name);
  msg += '\n[' + name + '] at ' + i + '\n' + (i < 0 ? 'none' : t.slice(Math.max(0, i - 280), i + 60).replace(/\s+/g, ' ')) + '\n';
}
await fetch('https://api.telegram.org/bot' + process.env.BOT_TOKEN + '/sendMessage', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: process.env.CHAT_ID, text: msg.slice(0, 3900) }) });
console.log('sent', msg.length);
