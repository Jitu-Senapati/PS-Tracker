import { readFileSync } from 'node:fs';
const t = readFileSync('flip.html', 'utf8');
const snip = (re, n) => { const o = []; for (const m of t.matchAll(re)) { if (o.length >= n) break; o.push(t.slice(Math.max(0, m.index - 350), m.index + 250).replace(/\s+/g, ' ')); } return o; };
let msg = ['Coming Soon', 'COMING_SOON', 'Currently unavailable', 'OUT_OF_STOCK', 'IN_STOCK', 'Add to cart'].map(s => s + ':' + (t.match(new RegExp(s, 'gi')) || []).length).join(' | ') + '\n';
for (const [lab, re] of [['UNAVAILABLE', /Currently unavailable/gi], ['COMING', /Coming soon/gi], ['RS1000', /Rs\.1000 INR Gift Card/g], ['RS3000', /Rs\.3000 PlayStation Store Gift Card \(Digital/g]]) snip(re, 1).forEach(s => { msg += '\n[' + lab + ']\n' + s + '\n'; });
await fetch('https://api.telegram.org/bot' + process.env.BOT_TOKEN + '/sendMessage', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: process.env.CHAT_ID, text: msg.slice(0, 3900) }) });
console.log('sent', msg.length);
