import { readFileSync } from 'node:fs';
const t = readFileSync(process.argv[3] || 'flip.html', 'utf8');
const labels = [...t.matchAll(/>(Currently unavailable|Coming Soon|Sold Out|Out of stock)<\/div>/gi)].map(m => ({ i: m.index, s: m[1] }));
const titles = [...t.matchAll(/<a[^>]*href="([^"]*\/p\/itm[^"]*)"[^>]*><span[^>]*>([^<]{5,160})<\/span><\/a>/g)].map(m => ({ i: m.index, u: m[1].replace(/&amp;/g, '&'), n: m[2] }));
let prev = -1; const seen = new Set(); const rows = [];
for (const x of titles) {
  const lab = labels.filter(l => l.i > prev && l.i < x.i).pop();
  prev = x.i;
  const id = (x.u.match(/\/p\/(itm[a-z0-9]+)/i) || [])[1];
  if (!id || seen.has(id)) continue; seen.add(id);
  const amt = (x.n.match(/Rs\.?\s?(\d{3,5})/i) || x.n.match(/(\d{3,5})\s*INR/i) || x.n.match(/: (\d{3,5})/) || [])[1] || '?';
  rows.push(amt + ' | ' + (lab ? lab.s : 'NO LABEL') + ' | ' + x.u.split('?')[0].slice(0, 90));
}
const msg = 'labels:' + labels.length + ' titles:' + titles.length + ' unique:' + rows.length + '\n\n' + rows.join('\n');
if (process.argv[2] === 'test') console.log(msg);
else {
  await fetch('https://api.telegram.org/bot' + process.env.BOT_TOKEN + '/sendMessage', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: process.env.CHAT_ID, text: msg.slice(0, 3900) }) });
  console.log('sent', rows.length);
}
