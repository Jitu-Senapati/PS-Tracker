import { writeFileSync } from 'node:fs';
const url = process.argv[2];
const r = await fetch(url, { redirect: 'follow', headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36', 'accept-language': 'en-IN,en;q=0.9' } });
const t = await r.text();
writeFileSync('flip.html', t);
const titles = new Map();
for (const m of t.matchAll(/"(?:title|name|productName)":"([^"]{5,140})"/g)) if (/playstation|psn|gift card/i.test(m[1])) titles.set(m[1], (titles.get(m[1]) || 0) + 1);
const flags = new Map();
for (const m of t.matchAll(/"(availability|inStock|isAvailable|productStatus|stockStatus|availabilityStatus)":("?[^,}"]+"?)/g)) { const k = m[1] + '=' + m[2]; flags.set(k, (flags.get(k) || 0) + 1); }
const c = s => (t.match(new RegExp(s, 'gi')) || []).length;
let msg = 'status ' + r.status + ' size ' + t.length + '\nfinal: ' + r.url.slice(0, 90) + '\n';
msg += 'Sold Out:' + c('Sold Out') + ' Notify Me:' + c('Notify Me') + ' Currently unavailable:' + c('Currently unavailable') + ' Out of stock:' + c('Out of stock') + '\n';
msg += '\nFLAGS:\n' + ([...flags].slice(0, 15).map(([k, v]) => k + ' x' + v).join('\n') || 'none') + '\n';
msg += '\nTITLES (' + titles.size + '):\n' + ([...titles].slice(0, 30).map(([k, v]) => k + ' x' + v).join('\n') || 'none');
await fetch('https://api.telegram.org/bot' + process.env.BOT_TOKEN + '/sendMessage', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: process.env.CHAT_ID, text: msg.slice(0, 3800) }) });
console.log('sent', r.status, t.length);
